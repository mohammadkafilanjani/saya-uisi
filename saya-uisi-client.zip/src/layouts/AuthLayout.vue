<template>
  <div>
    <div class="row">
      <div class="col-md-6 col-sm-0 col-xs-0" v-show="$q.screen.gt.sm">
        <div class="row justify-center items-center left-side" style="height: 100vh;">
          <div class="col-md-9">
            <div class="row justify-center text-center">
              <div class="col-md-12">
                <q-img width="240px" height="68px" src="~/assets/img/uisi-logo.png"></q-img>
              </div>
              <div class="col-md-12 ">
                <q-img src="~/assets/img/college.png"></q-img>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<style>
.left-side {
  overflow: hidden;
}
</style>
