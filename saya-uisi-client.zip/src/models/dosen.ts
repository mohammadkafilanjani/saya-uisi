export interface DosenOptions {
  name: string;
  id: number;
  label: string;
  value: number;
}

export interface DosenWithoutNIDN {
  name: string;
  id: string;
}
