export interface Pengumuman {
  id: string;
  title: string;
  author: string;
  content: string;
  announcement_date: string;
  image?: string[] | any;
}
