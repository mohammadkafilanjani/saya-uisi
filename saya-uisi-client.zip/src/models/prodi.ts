export interface ProgramStudiOptions {
  id: number;
  value: number;
  label: string;
  name: string;
}

export interface ProgamStudi {
  id: number;
  name: string;
}
